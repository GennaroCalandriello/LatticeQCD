JMI Beamer-Theme       |  Tabish Qureshi 2021.
----------------
1. Copy all the files in the folder jmi-beamer-template to the folder in which
   you are creating your beamer presentation.
   You can leave out sample-beamer-talk.pdf
2. Use the theme "JMI" using the command \usetheme{JMI}.
3. Do not use any colortheme.
4. If you are new to beamer, you can use the file jmi-beamer-talk.tex
   as a starting point for your presentation.
---------------------------------------------------
